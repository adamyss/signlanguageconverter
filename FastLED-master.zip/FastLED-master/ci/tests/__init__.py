"""FastLED test suite."""
