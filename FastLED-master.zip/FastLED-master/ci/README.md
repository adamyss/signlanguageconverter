This is the Continuous Integration tool that builds the product in various configurations.

Running

Install the python `uv` tool.

`pip install uv`

Now run the python in this directory

`uv run ci-compile.py`